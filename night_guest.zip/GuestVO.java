package net.daum.vo;

public class GuestVO { //네임피라미터 이름과 빈클래스 변수명,테이블 컬럼명을 같게 한다. => 데이터 저장빈 클래스
	
	private int gno;//방명록 번호
    private String gname;//글쓴이
    private String gtitle;//글제목
    private String gcont;//글내용
    private String gdate;//등록날짜
    
	public int getGno() {
		return gno;
	}
	public void setGno(int gno) {
		this.gno = gno;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGtitle() {
		return gtitle;
	}
	public void setGtitle(String gtitle) {
		this.gtitle = gtitle;
	}
	public String getGcont() {
		return gcont;
	}
	public void setGcont(String gcont) {
		this.gcont = gcont;
	}
	public String getGdate() {
		return gdate;
	}
	public void setGdate(String gdate) {
		this.gdate = gdate;
	}    
}
