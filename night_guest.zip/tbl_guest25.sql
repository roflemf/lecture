--tbl_guest25 방명록 테이블 생성
create table tbl_guest25(
  gno number(38) primary key --방명록 번호
  ,gname varchar2(100) not null --글쓴이
  ,gtitle varchar2(200) not null --글제목
  ,gcont varchar2(4000) not null --글내용
  ,gdate date --등록날짜  
);

select * from tbl_guest25 order by gno desc;

create sequence  bno_seq25
start with 1
increment By 1
nocache
nocycle; -- 시퀀스 최대값 도달시 최소값 1부터 다시 반복 안함.